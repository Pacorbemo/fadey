export const environment = {
  production: false,
  serverUrl: 'http://localhost:5000',
};