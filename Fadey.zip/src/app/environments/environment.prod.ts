export const environment = {
	production: true,
	serverUrl: 'https://servidor-remoto.com',
  };