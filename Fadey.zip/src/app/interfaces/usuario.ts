export interface Usuario {
	id: number;
	nombre: string;
	username: string;
	foto_perfil: string;
}
