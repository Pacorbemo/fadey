module.exports = function noAutoReserva(req, res, next) {
  
};